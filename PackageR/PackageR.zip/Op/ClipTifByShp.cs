﻿using RDotNet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageR.Op {
        class ClipTifByShp {
                static void help(string commandName) {
                        Console.WriteLine("程序名 " + commandName + " intif shp outtif extent");
                        Console.WriteLine("extent = true or false");
                        Console.WriteLine("extent = true 表示根据shp的extent进行裁剪");
                }
                static public void ToClipTifByShp(REngine eng, string commandName, string[] args) {
                        if (args.Length == 5) {
                                ToClipTifByShp(eng,args[1], args[2], args[3], args[4].ToLower() == "true");
                        } else {
                                eng.Dispose();
                                help(commandName);
                        }
                }
                static void ToClipTifByShp(REngine eng, string inTif,string shp,string outTif,bool mark) {
                        inTif = inTif.Replace("\\", "\\\\");
                        shp = shp.Replace("\\", "\\\\");
                        outTif = outTif.Replace("\\", "\\\\");
                        DebugForR dfr = new DebugForR(eng);
                        dfr.Command = "library(maptools)";
                        dfr.Command = "library(raster)";
                        dfr.Command = "library(rgdal)";
                        dfr.Command = "shp = readOGR('" + shp + "')";
                        dfr.Command = "r = raster('" + inTif + "')";
                        dfr.Command = "cr = crop(r,shp)";
                        if (mark) {
                                dfr.Command = "cr1 = mask(cr,shp);";
                                dfr.Command = "writeRaster(cr1,'" + outTif + "',overwrite=TRUE)";
                        } else {
                                dfr.Command = "writeRaster(cr,'" + outTif + "',overwrite=TRUE)";
                        }
                        eng.Dispose();
                }
        }
}
