﻿using RDotNet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageR.Op
{
        class ChangeDataType
        {
                static void Help(string commandName) {
                        Console.WriteLine("使用方法");
                        Console.WriteLine("program.exe " + commandName + " inTif outTif bands type");
                        Console.WriteLine("type 是数据类型，只有 float32 ");
                }
                static public void ChangeDataTypeHelp(REngine eng, string commandName, string[] args) {
                        if (args.Length == 5) {
                                List<int> bands = new List<int>();
                                args[3].Split('#').ToList().ForEach(b => {
                                        bands.Add(int.Parse(b));
                                });
                                DoChangeDataType(eng,args[1], args[2], bands, "as.numeric");
                        } else {
                                Help(commandName);
                        }
                }
                /**
                 * changeCL = as.numeric 、 as.integer
                 */
                static void DoChangeDataType(REngine eng, string inTif,string outTif,List<int> bands,string changeCL)
                {
                        DebugForR dfr = new DebugForR(eng);
                        StringBuilder sb = new StringBuilder();
                        int t = 0;
                        inTif = inTif.Replace("\\", "\\\\");
                        outTif = outTif.Replace("\\", "\\\\");
                        sb.Clear();
                        dfr.Command = "library('raster');";
                        bands.ForEach(b => {
                                sb.Append((t == 0 ? "" : ",") + "t" + t);
                                dfr.Command = "t" + t + "=raster('" + inTif + "',band=" + b + ")";
                                dfr.Command = "raster::setValues(t" + t + "," + changeCL + "(v));";
                                t++;
                        });
                        dfr.Command = "writeRaster(stack(" + sb.ToString() + "),\"" + outTif + "\",overwrite=TRUE);";
                        dfr.Command = "#over";
                        eng.Dispose();
                }
        }
}
